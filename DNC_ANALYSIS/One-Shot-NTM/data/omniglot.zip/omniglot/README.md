# Omniglot

Download the [Omniglot dataset](https://github.com/brendenlake/omniglot) and unzip `python/images_background.zip` here.
